package au.com.benbos67.number_converter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberConverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumberConverterApplication.class, args);
	}

}
