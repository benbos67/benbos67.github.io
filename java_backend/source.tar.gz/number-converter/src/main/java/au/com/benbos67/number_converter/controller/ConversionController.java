package au.com.benbos67.number_converter.controller;

import au.com.benbos67.number_converter.request.NumberConversionRequest;
import au.com.benbos67.number_converter.service.ConversionService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConversionController {

    private final ConversionService conversionService;

    public ConversionController(ConversionService conversionService) {
        this.conversionService = conversionService;
    }

    @PostMapping(consumes = "application/json", path = "/convert")
    @CrossOrigin
    public String convert(@RequestBody NumberConversionRequest request) {
        return conversionService.numbersToText(request.getNumberString());
    }


}
