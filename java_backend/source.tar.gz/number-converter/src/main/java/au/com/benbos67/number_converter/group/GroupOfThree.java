package au.com.benbos67.number_converter.group;

import au.com.benbos67.number_converter.utils.NumberValidator;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

@Setter
@Getter
public class GroupOfThree {

    private int units = 0;
    private int tens = 0;
    private int hundreds = 0;

    public GroupOfThree(@NonNull String numberString) {
        if (numberString.length() != 3) {
            numberString = "000";
        }
        if (NumberValidator.parseNumeric(numberString)) {
            char[] charArray = numberString.toCharArray();
            hundreds = Integer.parseInt(String.valueOf(charArray[0]));
            tens = Integer.parseInt(String.valueOf(charArray[1]));
            units = Integer.parseInt(String.valueOf(charArray[2]));
        }
    }

    public int valueOf() {
        return (hundreds * 100) + (tens * 10) + units;
    }

}
