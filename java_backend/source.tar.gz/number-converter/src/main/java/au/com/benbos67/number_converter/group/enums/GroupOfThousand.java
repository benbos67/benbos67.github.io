package au.com.benbos67.number_converter.group.enums;

import lombok.Getter;

@Getter
public enum GroupOfThousand {

    /*
    Do not change the order of these enum constants; we rely on the ordinal.
     */
    UNITS("", 1L), // ordinal 0
    THOUSANDS("thousand", 1000L), // ordinal 1
    MILLIONS("million", 1000000L), // ordinal 2
    BILLIONS("billion", 1000000000L), // ordinal 3
    TRILLIONS("trillion", 1000000000000L); // ordinal 4

    String description;
    Long factor;

    GroupOfThousand(String description, Long factor) {
        this.description = description;
        this.factor = factor;
    }

}
