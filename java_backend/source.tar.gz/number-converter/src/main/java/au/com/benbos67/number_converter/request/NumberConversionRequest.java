package au.com.benbos67.number_converter.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class NumberConversionRequest {

    @JsonProperty("numberString")
    private String numberString;

}
