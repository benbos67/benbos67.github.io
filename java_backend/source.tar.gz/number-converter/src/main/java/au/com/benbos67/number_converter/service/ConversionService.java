package au.com.benbos67.number_converter.service;

import au.com.benbos67.number_converter.group.GroupOfThree;
import au.com.benbos67.number_converter.group.enums.GroupOfThousand;
import au.com.benbos67.number_converter.utils.NumberValidator;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class ConversionService {

    private static final String ZERO = "0";
    private boolean haveDollars = false;
    private boolean otherThanUnits = false;
    private StringBuilder dollarResult = new StringBuilder();
    private boolean badInput = false;

    public String numbersToText(String numbers) {

        badInput = false;
        // Some basic validation; we also do this in the front end.
        if (Strings.EMPTY.equals(numbers.replaceAll("\\.", Strings.EMPTY).replaceAll(ZERO, Strings.EMPTY))) {
            badInput = true;
        }
        String[] dollarsAndCents = numbers.split("\\.");
        if (dollarsAndCents.length > 2) {
            badInput = true;
        }
        Arrays.stream(dollarsAndCents).forEach(n -> {
            if (!NumberValidator.parseNumeric(n) && !Strings.EMPTY.equals(n)) {
                badInput = true;
            }
        });

        String dollars = dollarsAndCents[0];
        if (dollars.length() > 15) {
            badInput = true;
        }

        if (badInput) {
            return Strings.EMPTY;
        }

        this.haveDollars = false;
        this.otherThanUnits = false;
        this.dollarResult = new StringBuilder();

        Map<GroupOfThousand, GroupOfThree> groups = new HashMap<>();

        int lastGroupLength = dollars.length() % 3;
        if (lastGroupLength != 0) {
            dollars = ZERO.repeat(3 - lastGroupLength) + dollars;
        }
        String cents = (dollarsAndCents.length > 1) ? dollarsAndCents[1].substring(0, 2) : Strings.EMPTY;
        cents += ZERO.repeat(2 - cents.length());
        cents = ZERO + cents;
        GroupOfThree centsGroup = new GroupOfThree(cents);

        // Now process our groups of three digits
        int endIndex = dollars.length();
        int startIndex = endIndex - 3;
        int groupNumber = 0;

        while (startIndex >= 0) {
            String dollarString = dollars.substring(startIndex, endIndex);
            Optional<GroupOfThousand> ordinalToAdd = getGroupOfThousandByOrdinal(groupNumber);

            ordinalToAdd.ifPresent(ord -> {
                GroupOfThree groupToAdd = new GroupOfThree(dollarString);
                if (groupToAdd.valueOf() > 0) {
                    this.haveDollars = true;
                }
                groups.put(ord, groupToAdd);
            });
            endIndex = startIndex;
            startIndex = startIndex - 3;
            groupNumber++;
        }

        for (int i = 4; i >= 0; i--) {
            Optional<GroupOfThousand> groupOfThousand = getGroupOfThousandByOrdinal(i);
            groupOfThousand.ifPresent(got -> {
                Optional<GroupOfThree> group = Optional.ofNullable(groups.get(got));
                group.ifPresent(g -> {
                    if (g.valueOf() > 0) {
                        if (!this.otherThanUnits && !GroupOfThousand.UNITS.equals(got)) {
                            this.otherThanUnits = true;
                        }
                        if (GroupOfThousand.UNITS.equals(got)) {
                            if (this.otherThanUnits && g.valueOf() < 100) {
                                this.dollarResult.append("and ").append(groupToString(g));
                            } else {
                                this.dollarResult.append(groupToString(g));
                            }
                        } else {
                            this.dollarResult
                                    .append(groupToString(g))
                                    .append(" ")
                                    .append(got.getDescription());
                        }
                        this.dollarResult.append(" ");
                    }
                });
            });
        }
        if (haveDollars) {
            dollarResult.append("dollars");
        }
        if (centsGroup.valueOf() > 0) {
            if (this.haveDollars) {
                this.dollarResult.append(" and ");
            }
            this.dollarResult.append(groupToString(centsGroup)).append(" cents");
        }
        return this.dollarResult.toString();
    }

    private String lessThan100ToText(int tens, int units) {
        if (tens == 1) {
            switch (units) {
                case 9:
                    return "nineteen";
                case 8:
                    return "eighteen";
                case 7:
                    return "seventeen";
                case 6:
                    return "sixteen";
                case 5:
                    return "fifteen";
                case 4:
                    return "fourteen";
                case 3:
                    return "thirteen";
                case 2:
                    return "twelve";
                case 1:
                    return "eleven";
                case 0:
                    return "ten";
                default:
                    return Strings.EMPTY;
            }
        }
        String tensReturn = Strings.EMPTY;
        if (tens > 0) {
            tensReturn = tenToText(tens);
            if (units > 0) {
                tensReturn += "-";
            }
        }
        return tensReturn + unitToText(units);
    }

    private String tenToText(int number) {
        switch (number) {
            case 9:
                return "ninety";
            case 8:
                return "eighty";
            case 7:
                return "seventy";
            case 6:
                return "sixty";
            case 5:
                return "fifty";
            case 4:
                return "forty";
            case 3:
                return "thirty";
            case 2:
                return "twenty";
            default:
                return Strings.EMPTY;
        }
    }

    private String unitToText(int number) {
        switch (number) {
            case 9:
                return "nine";
            case 8:
                return "eight";
            case 7:
                return "seven";
            case 6:
                return "six";
            case 5:
                return "five";
            case 4:
                return "four";
            case 3:
                return "three";
            case 2:
                return "two";
            case 1:
                return "one";
            default:
                return Strings.EMPTY;
        }
    }

    private String groupToString(GroupOfThree group) {
        String hundredReturn = "";
        if (group.getHundreds() > 0) {
            hundredReturn = unitToText(group.getHundreds()) + " hundred";
            if (group.getTens() * 10 + group.getUnits() > 0) {
                hundredReturn += " and ";
            }
        }
        return hundredReturn + lessThan100ToText(group.getTens(), group.getUnits());
    }

    private Optional<GroupOfThousand> getGroupOfThousandByOrdinal(int ordinal) {
        return Arrays.stream(GroupOfThousand.values())
                .filter(g -> g.ordinal() == ordinal)
                .findFirst();
    }

}
