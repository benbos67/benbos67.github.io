package au.com.benbos67.number_converter.utils;

public class NumberValidator {

    public static boolean parseNumeric(String str) {
        try {
            Long.parseLong(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }

}
