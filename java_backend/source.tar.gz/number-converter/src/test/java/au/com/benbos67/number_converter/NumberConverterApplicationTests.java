package au.com.benbos67.number_converter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumberConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
